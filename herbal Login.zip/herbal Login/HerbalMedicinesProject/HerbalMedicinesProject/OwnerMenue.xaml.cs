﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HerbalMedicinesProject
{
    /// <summary>
    /// Interaction logic for OwnerMenue.xaml
    /// </summary>
    public partial class OwnerMenue : Window
    {
        public OwnerMenue()
        {
           
            InitializeComponent();
        }

        private void btnClosOwnerMenue_Click(object sender)
        {

        }

        private void btnClosOwnerMenue_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btnbacktoLogin_Click(object sender, RoutedEventArgs e)
        {
           
            var backtoLogin = new MainWindow();
            backtoLogin.Show();
            this.Close();
        }
    }
}
