﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HerbalMedicinesProject
{
    /// <summary>
    /// Interaction logic for SellerMenue.xaml
    /// </summary>
    public partial class SellerMenue : Window
    {
        public SellerMenue()
        {
            InitializeComponent();
        }

        private void btnClosSellerMenue_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        

        private void btnbacktoLogin_Click(object sender, RoutedEventArgs e)
        {
            var backtoLogin = new MainWindow();
            backtoLogin.Show();
            this.Close();
        }
    }
}
