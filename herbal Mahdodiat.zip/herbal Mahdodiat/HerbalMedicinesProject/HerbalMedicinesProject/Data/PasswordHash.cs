﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace HerbalMedicinesProject
{
    internal class PasswordHash
    {
        // saltتابع برای هش کردن با 
        public static string HashPassword(string password)
        {
            // تولید salt تصادفی
            byte[] salt = new byte[16];
            RandomNumberGenerator.Fill(salt);

           //تابع استخراج کلید(PBKDF2)
             Rfc2898DeriveBytes pbkdf2=new Rfc2898DeriveBytes(password, salt, 1000, HashAlgorithmName.SHA256);
            
                byte[] hash = pbkdf2.GetBytes(32);//تولید هش
                // saltترکیب هش و  
                byte[] saltAndHash = new byte[salt.Length + hash.Length];
                Array.Copy(salt, 0, saltAndHash, 0, salt.Length);
                Array.Copy(hash, 0, saltAndHash, salt.Length, hash.Length);
                return Convert.ToBase64String(saltAndHash);// تبدیل باینری به رشته
            
        }

        
        
    }
}
