﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using HerbalMedicinesProject.Data;

namespace HerbalMedicinesProject
{
    /// <summary>
    /// Interaction logic for ForgotPassword.xaml
    /// </summary>
    public partial class ForgotPassword : Window
    {
        public ForgotPassword()
        {
            InitializeComponent();
        }

        private void btnChang_Click(object sender, RoutedEventArgs e)
        {
            if (validateInput())
            {
                Person person = new Person();
                HerbalDB herbalDB = new HerbalDB();

                person.Id = txtNationalCode.Text.ToString();
                person.PhoneNumber = txtPhoneNumber.Text.ToString();
                person.FavoriteNumber = txtFavoriteNumber.Text.ToString();
                person.PasswordHash = txtNewPassword.Password;

                if (herbalDB.EditPassword(person))
                {
                    MessageBox.Show("✅ Password change was successful !", "Registration ", MessageBoxButton.OK);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Password change was unsuccessful !", "Registration ", MessageBoxButton.OK, MessageBoxImage.Error);
                    this.Close();
                }
;
            }

        }
        //محدودیت رمز جدید
        bool isValidNewPassword(string password)
        {
            if (txtNewPassword.Password.Length < 8 || txtNewPassword.Password.Length > 16)
            {
                return false;

            }
            bool hasletter = password.Any(char.IsLetter);
            bool hasDigit = password.Any(char.IsDigit);
            return hasDigit && hasletter;
        }

        //ارزیابی فید ها 
        public bool validateInput()
        {
            if (txtNationalCode.Text == "")
            {
                MessageBox.Show("National Code has not been entered.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            if (!Regex.IsMatch(txtNationalCode.Text, @"^\d+$"))
            {
                MessageBox.Show("National Code must containonly digits!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            if (txtNationalCode.Text.Length != 10)
            {
                MessageBox.Show("National Code must be 10 digits!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            //شماره تلفن
            if (txtPhoneNumber.Text == "")
            {
                MessageBox.Show("Phone Number has not been entered.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            if (!Regex.IsMatch(txtPhoneNumber.Text, @"^\d+$"))
            {
                MessageBox.Show("Phone Number must containonly digits!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            if (txtPhoneNumber.Text.Length != 11)
            {
                MessageBox.Show("Phone Number must be 11 digits!", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            ///عدد مورد علاقه
            if (txtFavoriteNumber.Text == "")
            {

                MessageBox.Show("Favorite Number has not been entered.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            //پسورد

            if (txtNewPassword.Password == "")
            {
                MessageBox.Show("Password has not been entered.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            if (!isValidNewPassword(txtNewPassword.Password))
            {
                MessageBox.Show("The password must contain at least one\nletter and one number,and be between 8 to\n16 characters long.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }


            if (txtRepeatNewPassword.Password == "")
            {
                MessageBox.Show("Repeat Password has not been entered.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            //برابر بودن پسورد و تکرار آن
            if (txtNewPassword.Password != txtRepeatNewPassword.Password)
            {
                MessageBox.Show("Password and confirmation do not match.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }
            return true;
        }


    }
}
